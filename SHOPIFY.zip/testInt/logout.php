<html>
<head>
<meta charset="utf-8"
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Step2Shopify</title>
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/custom.css" rel="stylesheet">

<div id="container">
<div id="top_div">
<div class="heading">
<h1 align="LEFT"><a href="index.php"><img src="img/logo.jpg" width="187" height="50" alt="" class="img-thumbnail"/></a>   Step2Shopify</h1></div></div>
</div></div></div>
</head>
<body>
<div id="bottom_div">
<h1> Thank you for shopping with us </h1>
<img src="img/d1.jpg" alt="" class="img-thumbnail" align="centre"/>
</div>
</body>
</html>